# online-test-app [full stack application]




## Angular is a complete front end framework with a wide range of features

    Strong Module System
    Strong Component System
    Forms Handling
    Routing System
    Dependency Injection
    HTTP Requests

#Spring Boot is an awesome framework to build RESTful API 
